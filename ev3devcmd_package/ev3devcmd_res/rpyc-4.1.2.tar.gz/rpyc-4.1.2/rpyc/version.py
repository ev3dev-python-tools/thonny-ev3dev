version = (4, 1, 2)
version_string = ".".join(map(str, version))
release_date = "2019.10.03"
