The ev3devcmd package 

